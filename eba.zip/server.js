const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static('.')); // Serve arquivos estáticos da raiz

// Configuração do banco de dados
const db = new sqlite3.Database('testes.db'); // Aqui o arquivo será criado

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        score INTEGER NOT NULL,
        date TEXT NOT NULL
    )`);
});

// Registro de usuário
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = bcrypt.hashSync(password, 10);

    db.run(`INSERT INTO users (username, password) VALUES (?, ?)`, [username, hashedPassword], function(err) {
        if (err) {
            return res.status(400).json({ message: 'Usuário já existe' });
        }
        res.status(201).json({ id: this.lastID });
    });
});

// Login de usuário
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    db.get(`SELECT * FROM users WHERE username = ?`, [username], (err, row) => {
        if (row && bcrypt.compareSync(password, row.password)) {
            res.json({ success: true });
        } else {
            res.status(401).json({ message: 'Credenciais inválidas' });
        }
    });
});

// Carregar perguntas do arquivo JSON
app.get('/questions', (req, res) => {
    fs.readFile('questions.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao carregar perguntas' });
        }
        res.json(JSON.parse(data));
    });
});

// Salvar resultados
app.post('/results', (req, res) => {
    const { username, score } = req.body;
    const date = new Date().toISOString(); // Obtém a data e hora no formato ISO

    db.run(`INSERT INTO results (username, score, date) VALUES (?, ?, ?)`, [username, score, date], function(err) {
        if (err) {
            return res.status(400).json({ message: 'Erro ao salvar resultado' });
        }
        res.status(201).json({ id: this.lastID });
    });
});

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
