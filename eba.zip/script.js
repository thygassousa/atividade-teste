let questions = [];
let currentQuestionIndex = 0;
let score = 0;
let username = '';

function showRegister() {
    document.getElementById('login').style.display = 'none';
    document.getElementById('register').style.display = 'block';
}

function showLogin() {
    document.getElementById('register').style.display = 'none';
    document.getElementById('login').style.display = 'block';
}

async function register() {
    const regUsername = document.getElementById('reg-username').value;
    const regPassword = document.getElementById('reg-password').value;

    const response = await fetch('/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: regUsername, password: regPassword })
    });

    if (response.ok) {
        alert('Registro bem-sucedido!');
        showLogin();
    } else {
        alert('Erro ao registrar. Tente outro usuário.');
    }
}

async function login() {
    username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const response = await fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    if (response.ok) {
        document.getElementById('login').style.display = 'none';
        document.getElementById('quiz').style.display = 'block';
        loadQuestions();
    } else {
        alert('Credenciais inválidas.');
    }
}

async function loadQuestions() {
    const response = await fetch('/questions');
    questions = await response.json();
    displayQuestion();
}

function displayQuestion() {
    const questionContainer = document.getElementById('question-container');
    const question = questions[currentQuestionIndex];

    if (currentQuestionIndex < questions.length) {
        questionContainer.innerHTML = `
            <h2>${question.question}</h2>
            ${question.options.map((option, index) => `
                <label>
                    <input type="radio" name="option" value="${index}">
                    ${option}
                </label>
            `).join('')}
        `;
    } else {
        showResult();
    }
}

function nextQuestion() {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    if (selectedOption) {
        if (parseInt(selectedOption.value) === questions[currentQuestionIndex].answer) {
            score++;
        }
        currentQuestionIndex++;
        displayQuestion();
    } else {
        alert('Por favor, selecione uma opção.');
    }
}

function showResult() {
    const result = document.getElementById('result');
    result.style.display = 'block';
    result.innerHTML = score >= 7 ?
        `<h2>Você acertou ${score} de ${questions.length}!</h2><p>Parabéns, você atingiu a nota!</p>` :
        `<h2>Você acertou ${score} de ${questions.length}.</h2><p>Tente novamente!</p>`;

    saveResult();
}

async function saveResult() {
    const response = await fetch('/results', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, score })
    });

    if (!response.ok) {
        console.error('Erro ao salvar o resultado');
    }
}

